This is a simple calculator that will perform addition, subtraction, multiplication, division, floor divsion and modules 



 classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],

    